These are the Arduino sketches used in my Physical Computing with Arduino class, taught at Art Center College
of Design, Spring 2012 term.

Chris Spurgeon
chris@spurgeonworld.com
